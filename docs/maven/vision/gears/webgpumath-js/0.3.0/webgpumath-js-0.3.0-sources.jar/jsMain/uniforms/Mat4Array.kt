package vision.gears.webgpumath

import org.khronos.webgl.Float32Array
import org.khronos.webgl.get
import org.khronos.webgl.set
import kotlin.reflect.KProperty
import kotlin.random.Random
import kotlin.math.pow


class Mat4Array(backingStorage: Float32Array?, startIndex: Int = 0, endIndex: Int = 0) : UniformFloat {

  constructor(size : Int) : this(null, size, size) {}

  override var storage = backingStorage?.subarray(startIndex*16, endIndex*16)?:Float32Array(startIndex*16)

  override fun set(vararg values : Float) : Mat4Array {
    for(i in 0 until storage.length) {
      storage[i] = values.getOrNull(i%16) ?: if(i%16%5==0) 1.0f else 0.0f
    }
    return this
  }

  operator fun get(i : Int) : Mat4{
    return Mat4(storage, i*16)
  }

  operator fun provideDelegate(
      owner: UniformOwner,
      property: KProperty<*>) : Mat4Array{
    return owner.provider.bindUniform(property.name, this)
  }

  operator fun getValue(owner: UniformOwner, property: KProperty<*>): Mat4Array {
    return this
  }
  
  operator fun setValue(owner: UniformOwner, property: KProperty<*>, value: Mat4Array) {
    set(value)
  }    


  fun subarray(begin : Int, end : Int) : Mat4Array {
    return Mat4Array(storage, begin, end)
  }

  fun fill(value : Mat4) {
    for(i in 0 until storage.length/16) {
      get(i).set(value)
    }
  } 

}
